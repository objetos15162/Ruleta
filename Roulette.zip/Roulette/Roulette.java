import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Roulette extends Actor
{
    public void act() 
    {
        
    }    
}
